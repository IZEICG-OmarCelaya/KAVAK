import React from 'react';
import { VERSION } from '@twilio/flex-ui';
import { FlexPlugin } from '@twilio/flex-plugin';
import reducers, { namespace } from './states';

const PLUGIN_NAME = 'NotificationPlugin';

export default class NotificationPlugin extends FlexPlugin {
  constructor() {
    super(PLUGIN_NAME);
  }

  /**
   * This code is run when your plugin is being started
   * Use this to modify any UI components or attach to the actions framework
   *
   * @param flex { typeof import('@twilio/flex-ui') }
   * @param manager { import('@twilio/flex-ui').Manager }
   */
  async init(flex, manager) {
    this.registerReducers(manager);

    let alertSound = new Audio("https://jet-raven-2625.twil.io/assets/sweet_text.mp3");
    alertSound.loop = true;
    const resStatus = ["accepted", "canceled", "rejected", "rescinded", "timeout"];
    manager.workerClient.on("reservationCreated", async function (reservation) {
      if(reservation.task.attributes.conversations?.preceded_by === "Power Dialer"){
        console.log("IZEI-LOG: si es powerDIALER" )
        flex.TaskInfoPanel.Content.replace(
          <div className="Twilio-Tab css-1vw3tqz" key={"customInfoPanel"}>
            <div className="Twilio Twilio-TaskInfoPanel css-1mieabv">
              <div className="Twilio-TaskInfoPanel-default css-18ljn0d">
                <span className="Twilio">
                  <h1>TASK CONTEXT</h1>
                  <h2>Task type</h2>
                  <p data-test="task-type">{reservation.task.taskChannelUniqueName}</p>
                  <h2>Task priority</h2>
                  <p data-test="task-priority">{reservation.task.priority} </p>
                  <h2>Task queue</h2>
                  <p data-test="task-queue">{reservation.task.attributes.queue}</p>
                  <h2>Task Sid</h2>
                  <p data-test="task-sid">{reservation.task.sid} </p>
                  <h2>Reservation Sid</h2>
                  <p data-test="reservation-sid">{reservation.task.reservationSid} </p>
                  <hr />
                  <h1>CUSTOMER CONTEXT</h1>
                  <h2>Customer name / phone number</h2>
                  <p data-test="customer-name-number">{reservation.task.attributes.to}</p>
                  <h2>Called ID</h2>
                  <p data-test="customer-country">{reservation.task.attributes.from}</p>
                  <h2>Extra</h2>
                  <p>{reservation.task.attributes.conversations.externalId}</p>
                  <hr />
                  <h1>ADDONS</h1>
                  <p>
                    No add-ons enabled.
                    To expand your experience, visit
                  </p>
                  <a href="https://www.twilio.com/marketplace/add-ons" target="blank">Twilio Marketplace</a>
                </span>
              </div>
              <div class="Twilio-TaskInfoPanel-end css-wicpu5"></div>
            </div>
          </div>
        );
      }
      if (reservation.task.taskChannelUniqueName === 'voice' && reservation.task.attributes.direction != "outbound") {
        alertSound.play()
        if (reservation.task.attributes.conversations.conversation_attribute_1 === "") {
          await reservation.task.setAttributes({
            ...reservation.task.attributes,
            conversations: {
              ...reservation.task.attributes.conversations,
              conversation_attribute_1: manager.workerClient.attributes.email
            }
          })
          reservation.task.setAttributes({
            ...reservation.task.attributes,
            conversations: {
              ...reservation.task.attributes.conversations,
              conversation_attribute_1: manager.workerClient.attributes.email
            }
          })
          console.log("IZEI-LOG: VALOR: " + reservation.task.attributes.conversations.conversation_attribute_1)
        }
        else {
          console.log("IZEI-LOG: VALOR ELSE: " + reservation.task.attributes.conversations.conversation_attribute_1);
          await reservation.task.setAttributes({
            ...reservation.task.attributes,
            conversations: {
              ...reservation.task.attributes.conversations
            }
          })
        }
      };
      resStatus.forEach((e) => {
        reservation.on(e, () => {
          alertSound.pause()
        });
      });
    });

  }

  /**
   * Registers the plugin reducers
   *
   * @param manager {Flex.Manager}
          */
  registerReducers(manager) {
    if (!manager.store.addReducer) {
      // eslint-disable-next-line
      console.error(`You need FlexUI > 1.9.0 to use built-in redux; you are currently on ${VERSION}`);
      return;
    }

    manager.store.addReducer(namespace, reducers);
  }
}
