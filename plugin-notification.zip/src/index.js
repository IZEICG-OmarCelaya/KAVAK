import * as FlexPlugin from '@twilio/flex-plugin';

import NotificationPlugin from './NotificationPlugin';

FlexPlugin.loadPlugin(NotificationPlugin);
