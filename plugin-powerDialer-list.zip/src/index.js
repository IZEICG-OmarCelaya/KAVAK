import * as FlexPlugin from '@twilio/flex-plugin';

import PowerDialerListPlugin from './PowerDialerListPlugin';

FlexPlugin.loadPlugin(PowerDialerListPlugin);
