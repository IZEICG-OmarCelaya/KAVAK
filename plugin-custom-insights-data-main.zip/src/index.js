import * as FlexPlugin from '@twilio/flex-plugin';

import CustomInsightsDataMainPlugin from './CustomInsightsDataMainPlugin';

FlexPlugin.loadPlugin(CustomInsightsDataMainPlugin);
