var appConfig = {
  pluginService: {
    enabled: true,
    url: '/plugins',
  },
  logLevel: 'info',
};
