import React, { Component } from 'react';
import { StyledButton } from './styles';
import { connect } from 'react-redux';
import { Actions, withTheme } from '@twilio/flex-ui';
import { request } from './ServerlessClient'
class GetTask extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
        this.handleClick = this.handleClick.bind(this);
    }
    async handleClick(event) {
        // for (let x in this.props.flex.Manager) { console.log("IZEI-LOG: " + x); }
        // manager.workerClient.attributes
        let callSid= this.props.task._source.attributes.conference.participants.customer
        let workerSid = this.props.workerSid;
        console.log("IZEI-LOG: " + callSid);
        console.log("IZEI-LOG: " + workerSid);

         //definir la data para ejecutar la funcion: GetTask
         let data = {
            callSid: callSid, 
            workerSid: workerSid
        };
        //Se define el nombre de la funcion.
        let GetTask = "PickTask";
        //se ejecuta la funcion: "GetTask" y se guarda el resultado en la constante: "resultGetTask"
        const resultGetTask = await request(GetTask, this.props.manager, data);
        let response = resultGetTask.body;
        console.table({
            twilioFunction: GetTask,
            statusCode: resultGetTask.statusCode,
            message: resultGetTask.message,
            respuesta: JSON.stringify(response)
        });
        // this.setState({ GetTask: response });
    }

    render() {
        return (
            <StyledButton
                color={this.props.theme.colors.base11}
                background={this.props.theme.colors.base2}
                type="button"
                // className="btn btn-success me-5 mt-2"
                disabled={false}
                title="Contactos"
                aria-describedby={this.id}
                variant="contained"

                onClick={this.handleClick}
            >
                Transfer
            </StyledButton>
        );
    }
}
const mapStateToProps = (state, ownProps) => {
    let currentTask = false;
    state.flex.worker.tasks.forEach((task) => {
        if (ownProps.channelSid === task.attributes.channelSid) {
            currentTask = task;
        }
    })

    return {
        state,
        currentTask,
    }
}

export default connect(mapStateToProps)(withTheme(GetTask));