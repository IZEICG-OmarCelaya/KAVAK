import * as FlexPlugin from '@twilio/flex-plugin';

import SupervisorCoachPlugin from './SupervisorCoachPlugin';

FlexPlugin.loadPlugin(SupervisorCoachPlugin);
