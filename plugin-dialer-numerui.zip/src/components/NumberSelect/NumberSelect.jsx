import React, { Component } from 'react'
import axios from "axios";
import { StyledSelect, Caption } from "./NumberSelect.Styles";
import MenuItem from "@material-ui/core/MenuItem";
import * as Flex from "@twilio/flex-ui";
import './searchBar.css'
import { Icon } from '@twilio/flex-ui';
// It is recommended to keep components stateless and use redux for managing states
class NumberSelect extends Component {

  constructor(props) {
    super(props);
    let result = [];
    if (this.props.skills.includes("Ventas_Inbound")) {
      result = ["Ventas_Inbound"]
    } else if (this.props.skills.includes("LO_Customer_Service")) {
      result = ["LO_Customer_Service"]
    } else if (this.props.skills.includes("Inbound_Wingman")) {
      result = ["Inbound_Wingman"]
    } else {
      result = this.props.skills.filter(skill => skill.includes("_OB"));
    }
    this.state = {
      callerIds: [],
      taskQueue: [
        {
          queue: "LO_Customer_Service",
          sid: "WQacd3b11758e0601cc5d927621b2f6953"
        },
        {
          queue: "Inbound_Wingman",
          sid: "WQf5fe734df8196311996106112002f0c2"
        },
        {
          queue: "Ventas_Inbound",
          sid: "WQ92f9b602be5ed741a4dec89cc7837151"
        },
        {
          queue: "Back-Office_OB",
          sid: "WQf67f9c7d3dcce9b87290f3170af3f171"
        },
        {
          queue: "Resolution_OB",
          sid: "WQfe14ab585662d4fec440cffdeaea52f3"
        },
        {
          queue: "Sales-Origination-Checkout_OB",
          sid: "WQec1fc10a051902c951e4a053f788baff"
        },
        {
          queue: "Sales-Origination-Premium_OB",
          sid: "WQ696c932fdf4a2aaa4728135642f29b5f"
        },
        {
          queue: "RSales-Origination-Regular_OB",
          sid: "WQ28bcea96f36dd2fef98c2f67fbad440f"
        },
        {
          queue: "Sales-Origination-Select_OB",
          sid: "WQ7a388e1abfe7c5c6a83278cc042f4edb"
        },
        {
          queue: "Sales-Origination-Botmaker_OB",
          sid: "WQ82b8817601cfefa8c9ab0e6ed9c984bd"
        },
        {
          queue: "Sales-EMs_OB",
          sid: "WQ57b4e4b6f94c107c93412f5d1093b5bf"
        },
        {
          queue: "Sales-FEMs_OB",
          sid: "WQ84e5f860d50f6caf57869ad085ea07a4"
        },
        {
          queue: "Sales-TIMs_OB",
          sid: "WQ76179903f363e90eacb7fa9a6aa78823"
        },
        {
          queue: "Supply-Origination-Outbound_OB",
          sid: "WQ3db4ed6c5eeee93faa3fededd0594deb"
        },
        {
          queue: "Supply-LMs_OB",
          sid: "WQd70de1ad013a1246a311ab83541c7e79"
        },
        {
          queue: "Supply-PP_OB",
          sid: "WQ60fe00dd5b211d9f3766b87d0c930467"
        }],
      skill: result,
      text: '',
      textSkill: '',
      filteredData: [],
      wordEntered: ''
    };
    if (result.length == 1) {
      this.state.textSkill = result[0];
      const nueva = this.state.taskQueue.find(elemement => elemement.queue.includes(result[0]));
      var event = new CustomEvent("OutCallModalControlOpen", {
        detail: {
          queue: nueva.sid
        }
      });
      document.dispatchEvent(event);
    }
    if (result.length < 1) {
      const newFilter = this.props.skills.filter((value) => {
        return value.includes(!"Outbound_Calls");
      });
      this.setState({ skill: newFilter })
    }

    this.getCallerIds = this.getCallerIds.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeSkill = this.handleChangeSkill.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.clearInput = this.clearInput.bind(this);
    this.getCallerIds();
  }

  async getCallerIds() {

    let url = 'https://api.twilio.com/2010-04-01/Accounts/AC87eecf75d622de4c558887b8bd13e9f4/IncomingPhoneNumbers/Local.json?Beta=false';

    var config = {
      method: 'get',
      url: url,
      headers: {
        'Authorization': 'Basic QUM4N2VlY2Y3NWQ2MjJkZTRjNTU4ODg3YjhiZDEzZTlmNDoxNTk3YTM0N2ZmZTVkMmI5MTY0ZmIyYjBhODMwYzkzZg==',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: data
    };

    const response = await axios(config);
    const data = response.data;

    // console.log(`🚀 ${data}`)
    // console.log(`🚀🚀 ${JSON.stringify(data)}`)
    // console.log(`🚀🚀🚀 ${data.incoming_phone_numbers}`)

    const callerIds = data.incoming_phone_numbers || [];
    // console.log(`🚀🚀🚀🚀 ${JSON.stringify(callerIds)}`)

    const callerIdsArray = [];

    for (let i = 0; i < callerIds.length; i++) {

      callerIdsArray.push({
        friendly_name: callerIds[i].friendly_name,
        phone_number: callerIds[i].phone_number
      });
    }
    console.log("IZEI-LOG: " + callerIdsArray);
    this.setState({ callerIds: callerIdsArray })
  };

  //SELECT DE QUEUES
  handleChangeSkill(e) {
    // for (let x in this.props) { console.log("😒IZEI-LOG: " + x); }
    this.setState({ textSkill: e.target.value });
    const nueva = this.state.taskQueue.find(elemement => elemement.queue.includes(e.target.value));
    console.log("IZEI-LOG: tu llamada saldra desde la queue " + nueva.queue + " con el sid: " + nueva.sid);
    var event = new CustomEvent("OutCallModalControlOpen", {
      detail: {
        queue: nueva.sid
      }
    });
    document.dispatchEvent(event);
    // this.props.updateQUEUE(nueva.sid);
  }

  handleChange(e) {
    // for (let x in e.target) { console.log("😒IZEI-LOG: " + x); }
    this.props.updateNumber(e.target.title);

    this.setState({ text: e.target.title })
    this.clearInput();
  }

  handleFilter(event) {
    const searchWord = event.target.value;

    this.setState({ wordEntered: searchWord })
    var Numeros = /^[+0-9]/;
    var Letras = /^[A-Za-z]/;
    var string = ""
    if (searchWord.match(Numeros)) {
      console.log("IZEI-LOG: ES NUMERO");
      const newFilter = this.state.callerIds.filter((value) => {
        return value.phone_number.includes(searchWord);
      });
      if (searchWord === "") {
        this.setState({ filteredData: [] })
      } else {
        this.setState({ filteredData: newFilter })

      }
    }
    if (searchWord.match(Letras)) {
      console.log("IZEI-LOG: ES LETRA");
      const newFilter = this.state.callerIds.filter((value) => {
        return value.friendly_name.toLocaleLowerCase().includes(searchWord.toLocaleLowerCase());
      });
      if (searchWord === "") {
        this.setState({ filteredData: [] })
      } else {
        this.setState({ filteredData: newFilter })

      }
    }
    // const newFilter = this.state.callerIds2.filter((value) => {
    //   return value.friendly_name.toLocaleLowerCase().includes(searchWord.toLocaleLowerCase());
    // });
    // if (searchWord === "") {
    //   this.setState({ filteredData: [] })
    // } else {
    //   this.setState({ filteredData: newFilter })

    // }
  };

  clearInput() {
    this.setState({ filteredData: [] })
    this.setState({ wordEntered: "" })
  };
  render() {
    return (
      <div>
        <Caption
          key="queue-select-caption"
          className="Twilio-OutboundDialerPanel-QueueSelect-Caption"
        >
          {"Caller Id: " + this.state.text}
        </Caption>
        <div className="search">
          <div className="searchInputs">
            <input
              type="text"
              placeholder={"Caller ID.."}
              value={this.state.wordEntered}
              onChange={this.handleFilter}
            />
            <div className="searchIcon">
              {this.state.filteredData.length === 0 ? (
                <Icon icon="AcceptLarge" />
              ) : (
                <button onClick={this.clearInput}>
                  <Icon id="clearBtn" icon="CloseLarge" />
                </button>

              )}
            </div>
          </div>
          {this.state.filteredData.length != 0 && (
            <div className="dataResult clearBtn">
              {this.state.filteredData.slice(0, 15).map((value, key) => {
                return (
                  <li className="dataItem"
                    id='clearBtn'
                    key={key}
                    onClick={this.handleChange}
                    value={value.phone_number}
                    title={value.phone_number}
                  >{value.friendly_name} </li>
                );
              })}
            </div>
          )}
        </div>
        <StyledSelect
          value={this.state.textSkill}
          onChange={this.handleChangeSkill}
        >
          <MenuItem key="placeholder" value="placeholder" disabled>
            COLA
          </MenuItem>
          {this.state.skill.map((element) => (
            <MenuItem key={element} value={element} name={element} >
              {element}
            </MenuItem>
          ))}
        </StyledSelect>
      </div>
    );
  }
};

export default NumberSelect;
