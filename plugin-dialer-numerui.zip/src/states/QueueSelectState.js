const UPDATE_DIALER_QUEUE = "UPDATE_QUEUE";
const INVALIDATE_DIALER_QUEUE = "INVALIDATE_QUEUE";
const VALIDATE_DIALER_QUEUE = "VALIDATE_QUEUE";
const ENABLE_QUEUE_SIDEBAR = "ENABLE_SIDEBAR";
const DISABLE_QUEUE_SIDEBAR = "DISABLE_SIDEBAR";
const SET_DIALER_DESTINATION = "DIALER_DESTINATION";
const AUTO_INVALIDATE_QUEUE = "AUTO_INVALIDATE_QUEUE";

const initialState = {
    isConfirmed: false,
    showSidebar: false,
    invalidateQUEUE: false,
};

export class Actions2 {
    static updateQUEUE = (QUEUE) => ({
        type: UPDATE_DIALER_QUEUE,
        QUEUE,
    });

    static setToQUEUE = (QUEUE) => ({
        type: SET_DIALER_DESTINATION,
        QUEUE,
    });

    static invalidateQUEUE = () => ({ type: INVALIDATE_DIALER_QUEUE });
    static validateQUEUE = () => ({ type: VALIDATE_DIALER_QUEUE });
    static enableSideBar = () => ({ type: ENABLE_QUEUE_SIDEBAR });
    static disableSideBar = () => ({ type: DISABLE_QUEUE_SIDEBAR });
    static setAutoInvalidate = (invalidate) => ({
        type: AUTO_INVALIDATE_QUEUE,
        invalidate,
    });
}

export function reduce(state = initialState, action) {
    switch (action.type) {
        case UPDATE_DIALER_QUEUE: {
            return {
                ...state,
                QUEUE: action.QUEUE,
                isConfirmed: true,
            };
        }

        case INVALIDATE_DIALER_QUEUE: {
            if (!state.invalidateQUEUE) {
                return state;
            }

            return {
                ...state,
                isConfirmed: false,
            };
        }

        case VALIDATE_DIALER_QUEUE: {
            return {
                ...state,
                isConfirmed: true,
            };
        }

        case ENABLE_QUEUE_SIDEBAR: {
            return {
                ...state,
                showSidebar: true,
                isConfirmed: true,
            };
        }
        case DISABLE_QUEUE_SIDEBAR: {
            return {
                ...state,
                showSidebar: false,
                isConfirmed: !state.invalidateQUEUE,
            };
        }

        case SET_DIALER_DESTINATION: {
            return {
                ...state,
                toQUEUE: action.QUEUE,
            };
        }

        case AUTO_INVALIDATE_QUEUE: {
            return {
                ...state,
                invalidateQUEUE: action.invalidate,
            };
        }

        default:
            return state;
    }
}
