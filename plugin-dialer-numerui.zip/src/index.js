import * as FlexPlugin from '@twilio/flex-plugin';

import DialerNumberuiPlugin from './DialerNumberuiPlugin';

FlexPlugin.loadPlugin(DialerNumberuiPlugin);
