import React from "react";
import * as Flex from "@twilio/flex-ui";
import { FlexPlugin } from "flex-plugin";
import NumberSelectContainer from "./components/NumberSelect/NumberSelect.Container";
import NumberSelectSideBarContainer from "./components/NumberSelectSideBar/NumberSelectSideBar.Container";
import reducers, { namespace } from "./states";
import { Actions } from "./states/NumberSelectState";
import { Actions2 } from "./states/QueueSelectState";
const PLUGIN_NAME = "DialerNumberuiPlugin";

export default class DialerNumberuiPlugin extends FlexPlugin {
  constructor() {
    super(PLUGIN_NAME);
  }

  /**
   * This code is run when your plugin is being started
   * Use this to modify any UI components or attach to the actions framework
   *
   * @param flex { typeof import('@twilio/flex-ui') }
   * @param manager { import('@twilio/flex-ui').Manager }
   */
  init(flex, manager) {
    this.registerReducers(manager);

    this.dispatch(
      Actions.setAutoInvalidate(
        manager.workerClient.attributes.autoInvalidate ?? true
      )
    );
    this.dispatch(
      Actions2.setAutoInvalidate(
        manager.workerClient.attributes.autoInvalidate ?? true
      )
    );
    const newFilter = flex.Manager.getInstance().workerClient.attributes.routing.skills.filter((value) => {
      return value.includes("_OB");
    });

    if (flex.Manager.getInstance().workerClient.attributes.routing.skills.includes("Outbound_Calls") || newFilter.length > 0) {
      console.log("IZEI-LOG: SI TIENE EL SKILLS ")
    } else {
      console.log("IZEI-LOG: NO TIENE EL SKILLS")

      flex.OutboundDialerPanel.Content.replace(
        <div key={'NotSkill'}>
          <h1>
            No tienes permisos necesarios para realizar llamadas.
          </h1>
        </div>
      );
    }

    console.log("IZEI-LOG: " + flex.Manager.getInstance().workerClient.attributes.routing.skills)
    let skill = flex.Manager.getInstance().workerClient.attributes.routing.skills
    flex.OutboundDialerPanel.Content.add(
      <NumberSelectContainer key="number-selector" skills={skill} />,
      { sortOrder: 1 }
    );

    flex.MainContainer.Content.add(
      <NumberSelectSideBarContainer key="numberSidebar" />,
      {
        align: "end",
      }
    );
    let QueueSid = "";
    document.addEventListener(
      "OutCallModalControlOpen",
      e => {
        QueueSid = e.detail.queue
        console.log("IZEI-LOG: " + QueueSid);
      },
      false
    );
    flex.Actions.replaceAction("StartOutboundCall", (payload, original) => {
      return new Promise((resolve, reject) => {
        if (payload.callerId) {
          resolve(payload.callerId);
          return;
        }

        if (
          !manager.store.getState()["dialer-numberui"].NumberSelect.isConfirmed
        ) {
          this.dispatch(Actions.setToNumber(payload.destination));
          this.dispatch(Actions.enableSideBar());
          reject("CallerId not confirmed, will show interface");
        }
        resolve(
          manager.store.getState()["dialer-numberui"].NumberSelect.phoneNumber
        );
      }).then((callerId) => {

        console.log(`😍${callerId}`)
        original({ ...payload, callerId: callerId, queueSid: QueueSid });
        this.dispatch(Actions.invalidateNumber());
      });
    });

    flex.Actions.on("afterToggleOutboundDialer", () => {
      if (manager.store.getState()["flex"].view.isOutboundDialerOpen) {
        this.dispatch(Actions.disableSideBar());
        this.dispatch(Actions.validateNumber());
      }
    });
  }

  dispatch = (f) => Flex.Manager.getInstance().store.dispatch(f);

  /**
   * Registers the plugin reducers
   *
   * @param manager { Flex.Manager }
   */
  registerReducers(manager) {
    if (!manager.store.addReducer) {
      // eslint: disable-next-line
      console.error(
        `You need FlexUI > 1.9.0 to use built-in redux; you are currently on ${Flex.VERSION}`
      );
      return;
    }

    manager.store.addReducer(namespace, reducers);
  }
}
