import * as FlexPlugin from '@twilio/flex-plugin';

import PowerDialerTaskPlugin from './PowerDialerTaskPlugin';

FlexPlugin.loadPlugin(PowerDialerTaskPlugin);
