exports.handler = async function(context, event, callback) {
    const { DOMAIN } = context;
    twiml = new Twilio.twiml.VoiceResponse();

    twiml.play({
        loop: 1
    }, `https://${DOMAIN}/espera.mp3`);
    twiml.pause({
        length: 5
    });
    // twiml.say("En un momento uno de nuestros agentes te atendera");
        
    callback(null, twiml);

};
