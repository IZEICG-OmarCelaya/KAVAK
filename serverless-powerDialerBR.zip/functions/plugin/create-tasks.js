const TokenValidator = require('twilio-flex-token-validator').functionValidator;

let path = Runtime.getFunctions()['plugin/utils'].path;
let assets = require(path);


const capitalize = (s) => {

  if (typeof s !== 'string') return ''

  return s.charAt(0).toUpperCase() + s.slice(1)
}


exports.handler = TokenValidator(async (context, event, callback) => {

  try {

    const client = context.getTwilioClient();

    const contacts = JSON.parse(event.contact);

    const { campaign } = event;

    for (let i = 0; i < contacts.length; i++) {

      const batchCode = event.batchCode ? event.batchCode : ""
      const destination = contacts[i].destination
      const name = contacts[i].name ? contacts[i].name : ""
      const queue = contacts[i].queue ? contacts[i].queue : ""
      const info = contacts[i].info ? contacts[i].info : ""
      const callerId = contacts[i].callerId ? contacts[i].callerId : context.TWILIO_NUMBER
      const externalId = contacts[i].externalId ? contacts[i].externalId : ""
      const retries = contact.retries ? contact.retries : 2;
      const retriesMin = contact.retriesMin;
      let optionalInfo = [];
      let actions = [];

      Object.keys(info).forEach((key) => {

        if (key.match("action_")) {

          actions = [...actions, { name: capitalize(key.replace("action_", "")), value: info[key] }];

        } else {

          optionalInfo = [...optionalInfo, { name: capitalize(key), value: info[key] }];

        }

      })

      await client.taskrouter.workspaces(context.WORKSPACE_SID)
        .tasks
        .create({
          attributes: JSON.stringify({
            name: "PD - " + name,
            queue,
            dialer: true,
            attempts: 1,
            callAfterTime: 0,
            retries: retries,
            retriesMin: retriesMin,
            numbers: destination.split("|"),
            currentNumberIdx: 0,
            channel: "voice",
            callerId: callerId,
            externalId:externalId,
            requiredInfo: {
              name,
              campaign
            },
            optionalInfo,
            actions,
            batchCode
          }
          ), workflowSid: context.WORKFLOW_SID
        });

    }

    callback(null, assets.response("json", {}));

  } catch (err) {

    callback(err);

  }


});